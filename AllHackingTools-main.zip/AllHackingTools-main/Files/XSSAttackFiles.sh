cd
cd
cd AllHackingTools
pip install bs4
git clone https://github.com/menkrep1337/XSSCon
chmod 755 -R XSSCon
cd XSSCon
cd
cd
cd AllHackingTools
git clone https://github.com/Ekultek/XanXSS
cd
cd
cd AllHackingTools
git clone https://github.com/s0md3v/XSStrike
cd
cd 
cd AllHackingTools
