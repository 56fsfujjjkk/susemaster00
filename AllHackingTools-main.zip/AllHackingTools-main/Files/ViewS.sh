clear
sleep 0.5
neofetch
sleep 1
cd
cd AllHackingTools
python3 src/Timer.py
cd
cd AllHackingTools
python2 src/aboutMenu.py   
