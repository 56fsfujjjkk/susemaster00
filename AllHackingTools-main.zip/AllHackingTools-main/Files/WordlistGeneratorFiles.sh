cd
cd
cd AllHackingTools
git clone https://github.com/Keshav2136/wlcreator 
cd wlcreator 
gcc -o wlcreator wlcreator.c 
cd
cd
cd AllHackingTools
git clone https://github.com/UndeadSec/GoblinWordGenerator.git
cd GoblinWordGenerator
cd
cd 
cd AllHackingTools
git clone https://github.com/Viralmaniar/SMWYG-Show-Me-What-You-Got.git
cd SMWYG-Show-Me-What-You-Got
pip2 install -r requirements.txt
cd
cd
cd AllHackingTools
