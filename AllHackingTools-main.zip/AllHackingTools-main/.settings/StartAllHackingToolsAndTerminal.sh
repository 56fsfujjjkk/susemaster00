cd
cd 
cd /data/data/com.termux/files/usr/etc/
rm -rf zshrc
cd
cd
cd AllHackingTools
cd Tool
cp zshrc /data/data/com.termux/files/usr/etc/
cd
cd
echo "cd && cd AllHackingTools && python2 MainMenu.py" > sTa4t.txt
cat "sTa4t.txt" >> /data/data/com.termux/files/usr/etc/zshrc
rm -rf sTa4t.txt
cd
cd
rm -rf sTa4t.txt

