red='\e[1;31m'
default='\e[0m'
yellow='\e[0;33m'
orange='\e[38;5;166m'
green='\033[92m'
g="\033[1;32m"
r="\033[1;31m"
b="\033[1;34m"
w="\033[0m"
o="\033[1;33m"
printf "\e[1;92m"

python3 ProgressBar.py
python3 Packages.py

sleep 2
clear
cd
cd
cd AllHackingTools
mv MainMenu.py /data/data/com.termux/files/home/AllHackingTools/Tool
clear
python3 .check/Configuration.py
