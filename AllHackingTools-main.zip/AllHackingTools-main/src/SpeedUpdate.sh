
cd 
cd
cd AllHackingTools
rm -rf .check
rm -rf .temp
rm -rf .logs
rm -rf .settings
rm -rf .desing
rm -rf Files
rm -rf src
rm -rf desing
rm -rf Castom
rm -rf Tool
rm -rf Help
rm -rf Themes
rm -rf Uninstall
rm -rf Termux-os
cd
cd
git clone https://github.com/mishakorzik/Termux-Setting
cd Termux-Setting
mv .check /data/data/com.termux/files/home/AllHackingTools
mv .desing /data/data/com.termux/files/home/AllHackingTools
mv .temp /data/data/com.termux/files/home/AllHackingTools
mv .logs /data/data/com.termux/files/home/AllHackingTools
mv .settings /data/data/com.termux/files/home/AllHackingTools
mv Files /data/data/com.termux/files/home/AllHackingTools
mv src /data/data/com.termux/files/home/AllHackingTools
mv Help /data/data/com.termux/files/home/AllHackingTools
mv Themes /data/data/com.termux/files/home/AllHackingTools
mv Termux-os /data/data/com.termux/files/home/AllHackingTools
mv Uninstall /data/data/com.termux/files/home/AllHackingTools
mv Castom /data/data/com.termux/files/home/AllHackingTools
cd 
cd
rm -rf Termux-Setting
cd 
cd
