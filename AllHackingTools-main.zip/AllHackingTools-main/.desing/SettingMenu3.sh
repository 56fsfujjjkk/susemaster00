echo '
  {01} - Logo Setting - d/n
  {02} - Menu Setting - d/n
  {03} - Vibration Setting - on/off
  {04} - Default Loading - on/off
  {05} - Special Opportunities
  {06} - View My Activity
  {07} - Delete My Activity
  {08} - Restore AllHackingTools backup
  {09} - Create AllHackingTools backup
  {10} - Exit System - log out AllHackingTools
  {11} - Back To MainMenu - Back To Main Menu '| lolcat -p 1.5
